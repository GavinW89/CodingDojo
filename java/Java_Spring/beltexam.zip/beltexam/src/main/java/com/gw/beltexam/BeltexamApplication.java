package com.gw.beltexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeltexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeltexamApplication.class, args);
	}

}
